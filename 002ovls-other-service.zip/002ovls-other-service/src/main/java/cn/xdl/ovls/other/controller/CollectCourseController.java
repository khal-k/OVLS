package cn.xdl.ovls.other.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import cn.xdl.ovls.common.entity.OvlsResult;
import cn.xdl.ovls.course.util.OvlsConstant;
import cn.xdl.ovls.other.entity.CollectCourse;
import cn.xdl.ovls.other.service.CollectCourseService;

@RestController
public class CollectCourseController {
	
	@Autowired
	private CollectCourseService collectService;
	
	/** 插入数据*/
	@RequestMapping(value="/insertCollectCourse",method=RequestMethod.POST)
	public OvlsResult insertCollect(Integer user_id,Integer course_id){
		OvlsResult result = new OvlsResult();
		//System.out.println(user_id+"=="+course_id);
		//创建一个收藏课程对象
		CollectCourse course = new CollectCourse();
		Date data = new Date();
		course.setCollectTime(data);
		course.setCourseId(course_id);
		course.setUserId(user_id);
		try{
			result = collectService.insertCourse(course);
		}catch(Exception e){
			result.setMsg(OvlsConstant.ERROR_MSG);
			result.setStatus(OvlsConstant.ERROR);
		}
		return result;
	}
	
	
	/** 根据用户id获取当前收藏课程的列表*/
	@RequestMapping(value="/findCollectCourseHistory",method=RequestMethod.GET)
	public OvlsResult collectCourse(Integer user_id){
		OvlsResult result = new OvlsResult();
		//System.out.println(user_id+"=="+course_id);
		//创建一个收藏课程对象
		try{
			result = collectService.selectByUserId(user_id);
		}catch(Exception e){
			result.setMsg(OvlsConstant.ERROR_MSG);
			result.setStatus(OvlsConstant.ERROR);
		}
		return result;
	}
	
	/** 根据收藏课程的id来删除收藏课程*/
	@RequestMapping(value="/deleteCollectCourseHistory",method=RequestMethod.POST)
	public OvlsResult deletecollectCourse(Integer id){
		OvlsResult result = new OvlsResult();
		//System.out.println(user_id+"=="+course_id);
		//创建一个收藏课程对象
		try{
			result = collectService.deleteColectCourseById(id);
		}catch(Exception e){
			result.setMsg(OvlsConstant.ERROR_MSG);
			result.setStatus(OvlsConstant.ERROR);
		}
		return result;
	}
	
	/** 根据收藏课程的id来删除收藏课程*/
	@RequestMapping(value="/findCourseIsExitedOrNot",method=RequestMethod.GET)
	public OvlsResult findCourseExited(Integer course_id){
		OvlsResult result = new OvlsResult();
		//System.out.println(user_id+"=="+course_id);
		//创建一个收藏课程对象
		try{
			result = collectService.findCollectCourseExitOrNot(course_id);
			//System.out.println(result.getStatus());
		}catch(Exception e){
			result.setMsg(OvlsConstant.ERROR_MSG);
			result.setStatus(OvlsConstant.ERROR);
		}
		return result;
	}
}
