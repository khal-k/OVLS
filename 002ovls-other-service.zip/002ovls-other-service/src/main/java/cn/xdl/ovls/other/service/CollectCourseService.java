package cn.xdl.ovls.other.service;

import cn.xdl.ovls.common.entity.OvlsResult;
import cn.xdl.ovls.other.entity.CollectCourse;

public interface CollectCourseService {
	
	/**
	 * 插入收藏课程数据
	 * @param course
	 * @return
	 */
	OvlsResult insertCourse(CollectCourse course);
	
	
	/**
	 * 根据用户id获取集合
	 * @param user_id
	 * @return
	 */
	OvlsResult selectByUserId(Integer user_id);
	
	
	/**
	 * 根据收藏课程的id进行收藏课程的删除
	 * @param id
	 * @return
	 */
	OvlsResult deleteColectCourseById(Integer id);
	
	/**
	 * 根据课程id 查询收藏课程中是否存在该课程
	 * @param id
	 * @return
	 */
	OvlsResult findCollectCourseExitOrNot(Integer course_id);
}













