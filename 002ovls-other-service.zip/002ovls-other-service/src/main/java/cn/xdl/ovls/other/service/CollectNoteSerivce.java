package cn.xdl.ovls.other.service;

import cn.xdl.ovls.common.entity.OvlsResult;
import cn.xdl.ovls.other.entity.CollectNote;

public interface CollectNoteSerivce {
	
	/**
	 * 可以插入一条课程笔记的数据
	 * @param note
	 * @return
	 */
	OvlsResult insertCollectNote(CollectNote note);
	
	/**
	 * 可以查询收藏笔记的方法
	 */
	OvlsResult findAllCollectNote(int user_id);
	
	/**
	 * 可以删除收藏笔记的方法
	 * @param id
	 * @return
	 */
	OvlsResult deleteCollectNote(int id);
	
	/**
	 *提供一个可以根据笔记id去查询是否有该笔记 
	 * @param id
	 * @return
	 */
	OvlsResult findCollectNoteIsOrNotExited(int note_id);
}





