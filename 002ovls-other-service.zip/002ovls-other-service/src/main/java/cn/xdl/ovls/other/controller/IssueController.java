package cn.xdl.ovls.other.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import cn.xdl.ovls.common.entity.OvlsResult;
import cn.xdl.ovls.course.util.OvlsConstant;
import cn.xdl.ovls.other.entity.Issue;
import cn.xdl.ovls.other.service.IssueService;

@RestController
public class IssueController {
	@Autowired
	private IssueService issueService;
	
	/** 用来查询事件集合,根据事件id*/
	@RequestMapping(value="/issue/{video_id}",method=RequestMethod.GET)
	//给要查询图书的集合赋初始值
	public OvlsResult loadEvaluateByVideoId(
			@PathVariable("video_id")int video_id){
		OvlsResult result = new OvlsResult();
		try{
			result = issueService.loadIssueByVideoId(video_id);
		}catch(Exception e){
			result.setMsg(OvlsConstant.ERROR_MSG);
			result.setStatus(OvlsConstant.ERROR);
		}
		return result;
	}
	
	/** 用来插入事件数据的 */
	@RequestMapping(value = "/issueInsert", method = RequestMethod.POST)
	// 给要查询图书的集合赋初始值
	public OvlsResult insertNote(String issue_context, Integer user_id, Integer video_id,String headline) {
		OvlsResult result = new OvlsResult();
		//System.out.println("11111");
		//System.out.println(issue_context+"=="+user_id+"=="+video_id+"=="+headline);
		Issue issue = new Issue();
		//创建日期
		Date date = new Date();
		issue.setHeadline(headline);
		issue.setPublishTime(date);
		issue.setUserId(user_id);
		issue.setVideoId(video_id);
		issue.setIssueContext(issue_context);
		
		try {
			 result=issueService.insertIssue(issue);
		} catch (Exception e) {
			result.setMsg(OvlsConstant.ERROR_MSG);
			result.setStatus(OvlsConstant.ERROR);
		}
		return result;
	}
	
	
	/** 用来插入事件数据的 */
	@RequestMapping(value = "/issueDelete", method = RequestMethod.POST)
	// 
	public OvlsResult deleteNote(Integer id) {
		OvlsResult result = new OvlsResult();
		//System.out.println("删除的id  "+id);
		try {
			 result=issueService.deleteIssue(id);
		} catch (Exception e) {
			result.setMsg(OvlsConstant.ERROR_MSG);
			result.setStatus(OvlsConstant.ERROR);
		}
		return result;
	}
	
	/** 用来插入事件数据的 */
	@RequestMapping(value = "/issueUpdata", method = RequestMethod.POST)
	// 
	public OvlsResult updataIssue(String headline,String context,Integer issue_id) {
		OvlsResult result = new OvlsResult();
		//创建一个时间对象
		Issue issue = new Issue();
		issue.setHeadline(headline);
		issue.setIssueContext(context);
		issue.setId(issue_id);
		Date d = new Date();
		issue.setPublishTime(d);
		
		//System.out.println(headline+"==="+context+"=="+issue_id);
		try {
			 result=issueService.updataIssue(issue);
		} catch (Exception e) {
			result.setMsg(OvlsConstant.ERROR_MSG);
			result.setStatus(OvlsConstant.ERROR);
			System.out.println(e.getMessage());
			System.out.println(e.getCause());
		}
		return result;
	}
	
	
	/** 用来查询事件集合,根据事件id,yonghu id*/
	@RequestMapping(value="/issueOnlyMe",method=RequestMethod.GET)
	//给要查询图书的集合赋初始值
	public OvlsResult loadissueOnlyMe(
				Integer video_id,Integer user_id){
		OvlsResult result = new OvlsResult();
		//System.out.println(video_id+"=="+user_id);
		try{
			result = issueService.selectIssuesByVideoIdAndUserId(video_id, user_id);
		}catch(Exception e){
			result.setMsg(OvlsConstant.ERROR_MSG);
			result.setStatus(OvlsConstant.ERROR);
		}
		return result;
	}
	
}





