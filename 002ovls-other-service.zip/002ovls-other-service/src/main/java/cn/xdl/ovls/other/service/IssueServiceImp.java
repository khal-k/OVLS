package cn.xdl.ovls.other.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.xdl.ovls.common.entity.OvlsResult;
import cn.xdl.ovls.common.util.OvlsConstant;
import cn.xdl.ovls.other.dao.IssueMapper;
import cn.xdl.ovls.other.entity.Issue;
@Service
public class IssueServiceImp implements IssueService {

	@Autowired
	private IssueMapper issueMapper;
	
	
	@Override
	/**
	 * 提供给用户一个可以查询问答信息的方法
	 */
	public OvlsResult loadIssueByVideoId(Integer video_id) {
		//使用分页...
				//PageHelper.startPage(1,size);
				//使用共有的方法,用从来存放图书信息集合,查找状态和语句
				OvlsResult result = new OvlsResult();
				//查询所有数据,根据价格排序
				List<Issue> list = issueMapper.selectByVideoId(video_id);
				if(list.isEmpty()==false){
					result.setStatus(OvlsConstant.OK);
					result.setMsg(OvlsConstant.LOAD_SUCCESSED);
					result.setObj(list);
					return result;
				}else{
					result.setStatus(OvlsConstant.ERROR);
					result.setMsg(OvlsConstant.LOAD_ERROR);
					//result.setObj(list);
					return result;
				}
	}


	@Override
	public OvlsResult insertIssue(Issue issue) {
		//先定义一个公共类
		OvlsResult result = new OvlsResult();
		//调用方法插入评论
		//System.out.println(issue.getVideoId()+"="+issue.getUserId());
		int row =issueMapper.insert(issue);
		if(row>0){
			result.setStatus(OvlsConstant.OK);
			result.setMsg(OvlsConstant.ISSUE_INSERT_OK);
		}else{
			result.setStatus(OvlsConstant.ERROR);
			result.setMsg(OvlsConstant.ISSUE_INSERT_ERROR);
		}
		return result;
	}


	@Override
	/**
	 * 提供一个方法,可以提供用户删除问答
	 */
	public OvlsResult deleteIssue(Integer id) {
		//先定义一个公共类
		OvlsResult result = new OvlsResult();
		//调用方法插入评论
		//System.out.println(issue.getVideoId()+"="+issue.getUserId());
		int row =issueMapper.deleteByPrimaryKey(id);
		if(row>0){
			result.setStatus(OvlsConstant.OK);
			result.setMsg(OvlsConstant.DELETE_OK);
		}else{
			result.setStatus(OvlsConstant.ERROR);
			result.setMsg(OvlsConstant.DELETE_ERROR);
		}
		return result;
	}
	
	
	@Override
	/**
	 * 提供一个可以修改问答内容,标题,时间的方法
	 */
	public OvlsResult updataIssue(Issue issue) {
		//先定义一个公共类
		OvlsResult result = new OvlsResult();
		//调用方法插入评论
		
		int row =issueMapper.updateByIssueId(issue);
		if(row>0){
			result.setStatus(OvlsConstant.OK);
			result.setMsg(OvlsConstant.UPDATE_OK);
		}else{
			result.setStatus(OvlsConstant.ERROR);
			result.setMsg(OvlsConstant.UPDATE_ERROR);
		}
		return result;
	}


	@Override
	public OvlsResult selectIssuesByVideoIdAndUserId(Integer video_id, Integer user_id) {
		//先定义一个公共类
		OvlsResult result = new OvlsResult();
		//调用方法插入评论
		
		List<Issue> list = issueMapper.selectByVideoIdAndVideoId(video_id, user_id);
		if(list.isEmpty()==false){
			result.setStatus(OvlsConstant.OK);
			result.setMsg(OvlsConstant.LOAD_SUCCESSED);
			result.setObj(list);
		}else{
			result.setStatus(OvlsConstant.ERROR);
			result.setMsg(OvlsConstant.UPDATE_ERROR);
		}
		return result;
	}

}
