package cn.xdl.ovls.other.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import cn.xdl.ovls.common.entity.OvlsResult;
import cn.xdl.ovls.course.util.OvlsConstant;
import cn.xdl.ovls.other.entity.CollectNote;
import cn.xdl.ovls.other.service.CollectNoteSerivce;

@RestController
public class CollectNoteController {
	@Autowired
	private CollectNoteSerivce noteService;
	
	/** 插入数据*/
	@RequestMapping(value="/insertCollectNote",method=RequestMethod.POST)
	
	public OvlsResult insertCollectNote(Integer user_id,Integer note_id){
		OvlsResult result = new OvlsResult();
		//创建一个收藏笔记的类
		CollectNote note = new CollectNote();
		Date d = new Date();
		note.setCollectTime(d);
		note.setNoteId(note_id);
		note.setUserId(user_id);
		try{
			result = noteService.insertCollectNote(note);
		}catch(Exception e){
			result.setMsg(OvlsConstant.ERROR_MSG);
			result.setStatus(OvlsConstant.ERROR);
		}
		return result;
	}
	
	/** 插叙数据*/
	@RequestMapping(value="/findAllCollectNote",method=RequestMethod.GET)
	
	public OvlsResult findCollectNote(Integer user_id){
		OvlsResult result = new OvlsResult();
		
		try{
			result = noteService.findAllCollectNote(user_id);
		}catch(Exception e){
			result.setMsg(OvlsConstant.ERROR_MSG);
			result.setStatus(OvlsConstant.ERROR);
		}
		return result;
	}
	
	/** 删除数据*/
	@RequestMapping(value="/deleteCollectNote",method=RequestMethod.POST)
	
	public OvlsResult deleteCollectNote(Integer id){
		OvlsResult result = new OvlsResult();
		
		try{
			result = noteService.deleteCollectNote(id);
		}catch(Exception e){
			result.setMsg(OvlsConstant.ERROR_MSG);
			result.setStatus(OvlsConstant.ERROR);
		}
		return result;
	}
	
	/** 删除数据*/
	@RequestMapping(value="/checkCollectNote",method=RequestMethod.GET)
	
	public OvlsResult findaCollectNote(Integer note_id){
		OvlsResult result = new OvlsResult();
		
		try{
			result = noteService.findCollectNoteIsOrNotExited(note_id);
		}catch(Exception e){
			result.setMsg(OvlsConstant.ERROR_MSG);
			result.setStatus(OvlsConstant.ERROR);
		}
		return result;
	}
	
}
