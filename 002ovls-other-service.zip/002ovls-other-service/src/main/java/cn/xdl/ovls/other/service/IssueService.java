package cn.xdl.ovls.other.service;

import cn.xdl.ovls.common.entity.OvlsResult;
import cn.xdl.ovls.other.entity.Issue;

public interface IssueService {
	
	/**
	 * 提供一个可以查询问答信息的方法
	 * @param video_id
	 * @return
	 */
	public OvlsResult loadIssueByVideoId(Integer video_id);
	
	
	/**
	 * 提供一个可以插入问答的方法
	 * @param issue
	 * @return
	 */
	public OvlsResult insertIssue(Issue issue);
	
	
	/**
	 * 提供一个可以删除问答的方法,根据问答id
	 * @param id
	 * @return
	 */
	public OvlsResult deleteIssue(Integer id);
	
	
	/**
	 * 提供一个可以更新问答内容,标题,时间的方法
	 * @param issue
	 * @return
	 */
	public OvlsResult updataIssue(Issue issue);
	
	/**
	 * 可以过滤只有该用户的评论的方法
	 */
	public OvlsResult selectIssuesByVideoIdAndUserId(Integer video_id,Integer user_id);
}




