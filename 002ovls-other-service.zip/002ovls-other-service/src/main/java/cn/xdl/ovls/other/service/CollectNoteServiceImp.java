package cn.xdl.ovls.other.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.xdl.ovls.common.entity.OvlsResult;
import cn.xdl.ovls.common.util.OvlsConstant;
import cn.xdl.ovls.other.dao.CollectNoteMapper;
import cn.xdl.ovls.other.entity.CollectNote;
@Service
public class CollectNoteServiceImp implements CollectNoteSerivce {
	@Autowired
	private CollectNoteMapper collectDao;
	
	@Override
	/**
	 * 用户插入收藏记录的
	 */
	public OvlsResult insertCollectNote(CollectNote note) {
		OvlsResult result = new OvlsResult();
		int row = collectDao.insert(note);
		if(row>0){
			result.setMsg(OvlsConstant.COLLECT_SUCCESS);
			result.setStatus(OvlsConstant.OK);
		}
		return result;
	}

	@Override
	/**
	 * 查询数据
	 */
	public OvlsResult findAllCollectNote(int user_id) {
		OvlsResult result = new OvlsResult();
		List<CollectNote> list = collectDao.selectByUserId(user_id);
		if(list.isEmpty()==false){
			result.setStatus(OvlsConstant.OK);
			result.setMsg(OvlsConstant.COLLECT_SUCCESS);
			result.setObj(list);
		}else{
			result.setStatus(OvlsConstant.ERROR);
		}
		return result;
	}

	@Override
	/*
	 * 删除数据
	 * (non-Javadoc)
	 * @see cn.xdl.ovls.other.service.CollectNoteSerivce#deleteCollectNote(int)
	 */
	public OvlsResult deleteCollectNote(int id) {
		OvlsResult result = new OvlsResult();
		int row = collectDao.deleteByPrimaryKey(id);
		if(row>0){
			result.setStatus(OvlsConstant.OK);
			result.setMsg(OvlsConstant.DELETE_OK);
		}else{
			result.setStatus(OvlsConstant.ERROR);
		}
		return result;
	}
	
	
	@Override
	/**
	 * 查询该笔记,根据笔记id
	 */
	public OvlsResult findCollectNoteIsOrNotExited(int note_id) {
		OvlsResult result = new OvlsResult();
		CollectNote note = collectDao.selectByNoteId(note_id);
		if(note==null){
			result.setStatus(OvlsConstant.OK);
		}else{
			result.setStatus(OvlsConstant.ERROR);
		}
		return result;
	}

}
