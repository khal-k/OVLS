package cn.xdl.ovls.other.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.xdl.ovls.common.entity.OvlsResult;
import cn.xdl.ovls.common.util.OvlsConstant;
import cn.xdl.ovls.other.dao.CollectCourseMapper;
import cn.xdl.ovls.other.entity.CollectCourse;
@Service 
public class CollecctCourseServiceImp implements CollectCourseService {
	@Autowired
	private CollectCourseMapper collectDao;
	
	@Override
	public OvlsResult insertCourse(CollectCourse course) {
		OvlsResult result = new OvlsResult();
		
		int row = collectDao.insert(course);
		if(row>0){
			result.setStatus(OvlsConstant.OK);
			result.setMsg(OvlsConstant.COLLECT_SUCCESS);
		}else{
			result.setStatus(OvlsConstant.ERROR);
			result.setMsg(OvlsConstant.LOAD_ERROR);
		}
		return result;
	}

	@Override
	public OvlsResult selectByUserId(Integer user_id) {
		OvlsResult result = new OvlsResult();
		
		List<CollectCourse> list = collectDao.selectByUserId(user_id);
		if(list.isEmpty()==false){
			result.setObj(list);
			result.setStatus(OvlsConstant.OK);
			result.setMsg(OvlsConstant.LOAD_SUCCESSED);
		}else{
			result.setStatus(OvlsConstant.ERROR);
		}
		return result;
	}
	
	@Override
	/**
	 * 可以删除用户的收藏课程的记录
	 */
	public OvlsResult deleteColectCourseById(Integer id) {
		OvlsResult result = new OvlsResult();
		
		int row = collectDao.deleteByPrimaryKey(id);
		if(row>0){
			result.setStatus(OvlsConstant.OK);
			result.setMsg(OvlsConstant.DELETE_OK);
		}else{
			result.setStatus(OvlsConstant.ERROR);
		}
		return result;
	}

	@Override
	/**
	 * 可以根据课程id查询该课程是否存在
	 */
	public OvlsResult findCollectCourseExitOrNot(Integer course_id) {
		OvlsResult result = new OvlsResult();
		
		CollectCourse course = collectDao.selectByCourseId(course_id);
		if(course==null){
			result.setStatus(OvlsConstant.OK);
		}else{
			result.setStatus(OvlsConstant.ERROR);
		}
		return result;	
	}
}










